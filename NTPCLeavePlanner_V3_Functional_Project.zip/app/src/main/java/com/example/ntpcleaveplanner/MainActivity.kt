package com.example.ntpcleaveplanner

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject

data class Leave(val id:String,val name:String,val type:String,val from:String,val to:String,val reason:String,val status:String)

class MainActivity: AppCompatActivity() {
    private val blue=Color.rgb(11,79,138); private val light=Color.rgb(234,243,251)
    private val gray=Color.rgb(102,112,133); private val prefs by lazy{getSharedPreferences("leave_db",0)}
    private lateinit var content:LinearLayout
    private val fmt=SimpleDateFormat("yyyy-MM-dd",Locale.US)
    private val display=SimpleDateFormat("dd MMM yyyy",Locale.US)
    private val team=mutableListOf(
        Leave("t1","Rohit Sharma","EL","2026-08-10","2026-08-13","Personal","Approved"),
        Leave("t2","Vikas Singh","EL","2026-08-12","2026-08-15","Family","Approved"),
        Leave("t3","Priya Verma","CL","2026-08-17","2026-08-20","Personal","Approved"),
        Leave("t4","Amit Kumar","HPL","2026-08-25","2026-08-27","Personal","Approved")
    )

    override fun onCreate(b:Bundle?){super.onCreate(b);showHome()}

    private fun root():LinearLayout{
        val r=LinearLayout(this);r.orientation=LinearLayout.VERTICAL;r.setBackgroundColor(Color.WHITE)
        val s=ScrollView(this);content=LinearLayout(this);content.orientation=LinearLayout.VERTICAL;content.setPadding(20,18,20,90);s.addView(content)
        r.addView(s,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this);nav.setPadding(4,4,4,4)
        listOf("⌂\nHome","＋\nApply","▦\nTeam","☷\nMy Leaves").forEachIndexed{i,x->
            val b=Button(this);b.text=x;b.textSize=11f;b.setTextColor(if(i==0)blue else gray);b.setBackgroundColor(Color.TRANSPARENT)
            b.layoutParams=LinearLayout.LayoutParams(0,72,1f);b.setOnClickListener{when(i){0->showHome();1->showApply();2->showTeam();3->showHistory()}};nav.addView(b)}
        r.addView(nav);return r
    }
    private fun setScreen(title:String,sub:String){setContentView(root());val t=TextView(this);t.text=title;t.textSize=25f;t.setTypeface(null,1);content.addView(t);val s=TextView(this);s.text=sub;s.textSize=14f;s.setTextColor(gray);content.addView(s);gap(16)}
    private fun gap(h:Int){content.addView(Space(this),LinearLayout.LayoutParams(1,h))}
    private fun card(title:String,body:String,highlight:Boolean=false){
        val c=LinearLayout(this);c.orientation=LinearLayout.VERTICAL;c.setPadding(17,14,17,14)
        val bg=GradientDrawable();bg.setColor(if(highlight)light else Color.rgb(248,250,252));bg.cornerRadius=22f;c.background=bg
        val a=TextView(this);a.text=title;a.textSize=13f;a.setTextColor(gray)
        val b=TextView(this);b.text=body;b.textSize=17f;b.setTypeface(null,1);b.setTextColor(Color.rgb(23,32,42));b.setPadding(0,6,0,0)
        c.addView(a);c.addView(b);content.addView(c);gap(9)
    }
    private fun button(text:String,action:()->Unit){val b=Button(this);b.text=text;b.setTextColor(Color.WHITE);b.setBackgroundColor(blue);b.setOnClickListener{action()};content.addView(b);gap(8)}
    private fun allLeaves():MutableList<Leave>{
        val out=team.toMutableList();val arr=JSONArray(prefs.getString("mine","[]"))
        for(i in 0 until arr.length()){val o=arr.getJSONObject(i);out.add(Leave(o.getString("id"),"You",o.getString("type"),o.getString("from"),o.getString("to"),o.getString("reason"),o.getString("status")))}
        return out
    }
    private fun overlap(a:String,b:String,c:String,d:String):Boolean{
        val x1=fmt.parse(a)!!.time;val x2=fmt.parse(b)!!.time;val y1=fmt.parse(c)!!.time;val y2=fmt.parse(d)!!.time
        return x1<=y2 && y1<=x2
    }
    private fun days(a:String,b:String):Long=((fmt.parse(b)!!.time-fmt.parse(a)!!.time)/(24*60*60*1000))+1
    private fun nearby(a:String,b:String,c:String,d:String):Boolean{
        val gapBefore=(fmt.parse(a)!!.time-fmt.parse(d)!!.time)/(24*60*60*1000)
        val gapAfter=(fmt.parse(c)!!.time-fmt.parse(b)!!.time)/(24*60*60*1000)
        return (gapBefore in 1..3)||(gapAfter in 1..3)
    }

    private fun showHome(){
        setScreen("Good morning, Avesh 👋","NTPC • C&I • Leave Planner")
        val mine=JSONArray(prefs.getString("mine","[]"));var approved=0;var pending=0
        for(i in 0 until mine.length()){when(mine.getJSONObject(i).getString("status")){"Approved"->approved++; "Pending"->pending++}}
        card("Leave balance","CL  •  12 days    |    EL  •  18 days",true)
        card("My requests","$approved approved  •  $pending pending")
        card("Team availability","${team.size} planned leaves in the current demo group")
        val upcoming=mine.optJSONObject(0)
        if(upcoming!=null)card("Next request","${upcoming.getString("from")} → ${upcoming.getString("to")}  •  ${upcoming.getString("status")}")
        val h=TextView(this);h.text="Quick actions";h.textSize=19f;h.setTypeface(null,1);content.addView(h);gap(7)
        button("＋  Apply Leave"){showApply()}
        button("▦  Check Team Calendar"){showTeam()}
    }

    private fun pickDate(target:EditText){
        val cal=Calendar.getInstance();DatePickerDialog(this,{_,y,m,d->target.setText(String.format(Locale.US,"%04d-%02d-%02d",y,m+1,d))},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun showApply(){
        setScreen("Apply Leave","Enter dates and check overlap before submitting")
        val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("CL","EL","HPL","Comp Off"));content.addView(type);gap(7)
        val from=EditText(this);from.hint="From (YYYY-MM-DD)";from.isFocusable=false;from.setOnClickListener{pickDate(from)};content.addView(from)
        val to=EditText(this);to.hint="To (YYYY-MM-DD)";to.isFocusable=false;to.setOnClickListener{pickDate(to)};content.addView(to)
        val reason=EditText(this);reason.hint="Reason";reason.minLines=3;content.addView(reason);gap(8)
        val result=LinearLayout(this);result.orientation=LinearLayout.VERTICAL;content.addView(result)
        button("Check Availability"){
            result.removeAllViews()
            val f=from.text.toString();val t=to.text.toString()
            if(!validRange(f,t)){toast("Please select valid dates");return@button}
            val overlaps=team.filter{overlap(f,t,it.from,it.to)}
            val near=team.filter{!overlap(f,t,it.from,it.to)&&nearby(f,t,it.from,it.to)}
            val total=days(f,t)
            val x=TextView(this);x.text="Selected: $total day(s)";x.textSize=17f;x.setTypeface(null,1);result.addView(x);gapIn(result,6)
            if(overlaps.isEmpty()){val ok=TextView(this);ok.text="✓ No team overlap detected";ok.setTextColor(Color.rgb(20,120,70));result.addView(ok)}
            else{val w=TextView(this);w.text="⚠ ${overlaps.size} overlapping leave(s)";w.textSize=16f;w.setTypeface(null,1);result.addView(w)
                overlaps.forEach{val ov=TextView(this);ov.text="${it.name}  •  ${it.from} → ${it.to}  •  ${overlapDays(f,t,it.from,it.to)} day overlap";ov.setPadding(0,7,0,7);result.addView(ov)}}
            if(near.isNotEmpty()){val n=TextView(this);n.text="Nearby leaves (within 3 days)";n.setTypeface(null,1);n.setPadding(0,12,0,4);result.addView(n);near.forEach{val q=TextView(this);q.text="${it.name}  •  ${it.from} → ${it.to}";q.setPadding(0,4,0,4);result.addView(q)}}
            val submit=Button(this);submit.text="Submit Leave Request";submit.setOnClickListener{saveLeave(type.selectedItem.toString(),f,t,reason.text.toString());showHistory()};result.addView(submit)
        }
    }
    private fun gapIn(parent:LinearLayout,h:Int){parent.addView(Space(this),LinearLayout.LayoutParams(1,h))}
    private fun validRange(a:String,b:String):Boolean=try{fmt.parse(a)!!.time<=fmt.parse(b)!!.time}catch(e:Exception){false}
    private fun overlapDays(a:String,b:String,c:String,d:String):Long{
        val start=maxOf(fmt.parse(a)!!.time,fmt.parse(c)!!.time);val end=minOf(fmt.parse(b)!!.time,fmt.parse(d)!!.time)
        return ((end-start)/(24*60*60*1000))+1
    }
    private fun saveLeave(type:String,f:String,t:String,reason:String){
        val arr=JSONArray(prefs.getString("mine","[]"));val o=JSONObject()
        o.put("id","m"+System.currentTimeMillis());o.put("type",type);o.put("from",f);o.put("to",t);o.put("reason",reason);o.put("status","Pending");arr.put(o)
        prefs.edit().putString("mine",arr.toString()).apply();toast("Leave request saved as Pending")
    }
    private fun showTeam(){
        setScreen("Team Calendar","Tap a period below to review planned leave")
        allLeaves().filter{it.name!="You"}.sortedBy{it.from}.forEach{card("${it.name}  •  ${it.type}","${it.from} → ${it.to}  •  ${it.status}")}
        card("Planning rule","When you select dates in Apply Leave, the app calculates overlaps and nearby leaves automatically.",true)
    }
    private fun showHistory(){
        setScreen("My Leaves","Saved locally on this device")
        val arr=JSONArray(prefs.getString("mine","[]"))
        if(arr.length()==0){card("No requests yet","Your submitted leave requests will appear here.");button("Apply your first leave"){showApply()};return}
        for(i in arr.length()-1 downTo 0){val o=arr.getJSONObject(i);card("${o.getString("type")}  •  ${o.getString("status")}","${o.getString("from")} → ${o.getString("to")}  •  ${o.getString("reason")}")}
        button("＋  Apply Another Leave"){showApply()}
    }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
}

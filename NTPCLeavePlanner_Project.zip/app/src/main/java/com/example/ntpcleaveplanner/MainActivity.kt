package com.example.ntpcleaveplanner

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val blue = Color.rgb(11,79,138)
    private val light = Color.rgb(234,243,251)
    private val gray = Color.rgb(102,112,133)
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun base(): LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL
        root.setBackgroundColor(Color.WHITE)
        val scroll=ScrollView(this); content=LinearLayout(this); content.orientation=LinearLayout.VERTICAL
        content.setPadding(22,20,22,90); scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this); nav.gravity=Gravity.CENTER; nav.setPadding(8,8,8,8)
        val items=listOf("⌂\nHome","＋\nApply","▦\nCalendar","☰\nMy Leaves")
        items.forEachIndexed { i, s ->
            val b=Button(this); b.text=s; b.textSize=11f; b.setTextColor(if(i==0) blue else gray)
            b.setBackgroundColor(Color.TRANSPARENT)
            b.layoutParams=LinearLayout.LayoutParams(0,70,1f)
            b.setOnClickListener { when(i){0->showDashboard();1->showApply();2->showCalendar();3->showHistory()} }
            nav.addView(b)
        }
        root.addView(nav); return root
    }

    private fun header(title:String, sub:String) {
        val t=TextView(this); t.text=title; t.textSize=25f; t.setTextColor(Color.rgb(23,32,42)); t.setTypeface(null,1)
        content.addView(t); val s=TextView(this); s.text=sub; s.textSize=14f; s.setTextColor(gray)
        content.addView(s); space(18)
    }

    private fun card(title:String, body:String, accent:Boolean=false): LinearLayout {
        val c=LinearLayout(this); c.orientation=LinearLayout.VERTICAL; c.setPadding(18,16,18,16)
        val bg=GradientDrawable(); bg.setColor(if(accent) light else Color.rgb(248,250,252)); bg.cornerRadius=22f
        c.background=bg; val tt=TextView(this); tt.text=title; tt.textSize=14f; tt.setTextColor(gray)
        val bb=TextView(this); bb.text=body; bb.textSize=18f; bb.setTextColor(Color.rgb(23,32,42)); bb.setTypeface(null,1); bb.setPadding(0,7,0,0)
        c.addView(tt); c.addView(bb); content.addView(c); space(10); return c
    }

    private fun space(h:Int){ val v=Space(this); content.addView(v,LinearLayout.LayoutParams(1,h)) }
    private fun button(text:String, click:()->Unit){ val b=Button(this); b.text=text; b.setTextColor(Color.WHITE); b.setBackgroundColor(blue); b.setOnClickListener{click()}; content.addView(b); space(8) }
    private fun showDashboard(){
        setContentView(base()); header("Good morning, Avesh 👋","NTPC • C&I • Leave Planner")
        card("Leave balance","18 days available",true)
        card("Next approved leave","12 Aug – 15 Aug 2026  •  CL")
        card("Team availability","⚠ 2 colleagues overlap your leave",true)
        val h=TextView(this); h.text="Around your leave"; h.textSize=19f; h.setTypeface(null,1); content.addView(h); space(8)
        card("Vikas Singh","12–15 Aug  •  EL  •  OVERLAP")
        card("Rohit Sharma","10–13 Aug  •  EL  •  OVERLAP")
        card("Priya Verma","17–20 Aug  •  CL  •  NEARBY")
        button("＋  Apply New Leave"){showApply()}
    }
    private fun showApply(){
        setContentView(base()); header("Apply Leave","Check team availability before submitting")
        val type=Spinner(this); type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Casual Leave (CL)","Earned Leave (EL)","Half Pay Leave (HPL)","Compensatory Off")); content.addView(type); space(10)
        val from=EditText(this); from.hint="From date  •  12 Aug 2026"; content.addView(from)
        val to=EditText(this); to.hint="To date  •  15 Aug 2026"; content.addView(to)
        val reason=EditText(this); reason.hint="Reason"; reason.minLines=3; content.addView(reason); space(10)
        button("Check Team Availability"){
            card("Overlap detected","2 colleagues are on leave during your selected period.",true)
            card("Vikas Singh","12–15 Aug  •  EL  •  4 days overlap")
            card("Rohit Sharma","10–13 Aug  •  EL  •  2 days overlap")
            button("Proceed to Apply"){ Toast.makeText(this,"Demo: application ready for submission",Toast.LENGTH_LONG).show() }
        }
    }
    private fun showCalendar(){
        setContentView(base()); header("Team Calendar","August 2026 • C&I Group")
        card("12–15 Aug","You + Vikas Singh are on leave",true)
        card("10–13 Aug","Rohit Sharma • Earned Leave")
        card("17–20 Aug","Priya Verma • Casual Leave")
        card("Leave planning insight","Your selected leave overlaps with 2 employees and is within 2 days of another leave.",true)
    }
    private fun showHistory(){
        setContentView(base()); header("My Leaves","Your leave requests and history")
        card("12–15 Aug 2026","CL • Approved")
        card("03–04 Jul 2026","CL • Approved")
        card("20–22 May 2026","EL • Approved")
        card("01–02 Apr 2026","CL • Pending")
    }
}
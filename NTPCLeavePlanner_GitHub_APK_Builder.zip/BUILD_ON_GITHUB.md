# Build the APK on GitHub

1. Create a GitHub repository.
2. Upload all files from this project to the repository.
3. Make sure `.github/workflows/build-apk.yml` is uploaded.
4. GitHub → Actions → **Build NTPC Leave Planner APK** → **Run workflow**.
5. When it finishes, open the workflow run.
6. Under **Artifacts**, download `NTPC-Leave-Planner-APK`.
7. Extract it and install `app-debug.apk` on your Android phone.

Note: the project should contain a Gradle wrapper (`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar`).
If Android Studio is used once to open the project, it can generate/sync the wrapper.
